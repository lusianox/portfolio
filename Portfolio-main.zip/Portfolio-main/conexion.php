<?php

// CONEXIÓN CON LA BASE DE DATOS PARA - - - USUARIOS QUE DESEEN CONTACTARSE - - -
$conex_db = mysqli_connect("localhost","id20169299_lucher","Soda0828213848Lu!","id20169299_portafolio"); 

?>